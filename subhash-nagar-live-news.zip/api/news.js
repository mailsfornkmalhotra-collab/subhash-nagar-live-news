export default async function handler(req, res) {
  const query =
    'Subhash Nagar OR West Delhi OR Rajouri Garden OR Tagore Garden OR Kirti Nagar OR Naraina OR Mayapuri OR Janakpuri';
  const apiUrl = `https://newsapi.org/v2/everything?q=${encodeURIComponent(
    query
  )}&language=en&sortBy=publishedAt&pageSize=10&apiKey=bc58b9e8f18e4318a60a6a3eb04a454e`;

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch news' });
  }
}